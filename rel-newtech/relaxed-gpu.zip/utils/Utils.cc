#include "Utils.h"

namespace Minisat {
    std::mutex SyncOut::lock;
}
